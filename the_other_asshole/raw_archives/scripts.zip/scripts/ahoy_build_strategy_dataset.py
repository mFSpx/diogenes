#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.training.strategy_dataset import build_strategy_dataset, default_feature_schema


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--games", type=Path, required=True, help="Directory or JSONL file containing raw Ahoy telemetry rows")
    ap.add_argument("--out-rows", type=Path, required=True)
    ap.add_argument("--out-packets", type=Path, required=True)
    ap.add_argument("--receipt-out", type=Path, required=True)
    ap.add_argument("--feature-schema", type=Path)
    ap.add_argument("--future-window", type=int, default=3)
    ap.add_argument("--limit", type=int)
    args = ap.parse_args()
    schema = json.loads(args.feature_schema.read_text()) if args.feature_schema and args.feature_schema.exists() else default_feature_schema()
    receipt = build_strategy_dataset(args.games, args.out_rows, args.out_packets, args.receipt_out, feature_schema=schema, future_window=args.future_window, limit=args.limit, command=" ".join(sys.argv))
    print(json.dumps({"verdict": receipt["verdict"], "rows": receipt["training_rows_written"], "packets": receipt["ontology_packets_written"], "receipt": str(args.receipt_out)}, sort_keys=True))
    return 0 if receipt["verdict"] in {"PASS", "PARTIAL_FAIL"} else 4

if __name__ == "__main__":
    raise SystemExit(main())
