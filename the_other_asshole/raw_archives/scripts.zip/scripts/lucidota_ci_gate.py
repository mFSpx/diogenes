#!/usr/bin/env python3
from __future__ import annotations
import json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'05_OUTPUTS/ci'
def ts():return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def rel(p):
 try:return str(Path(p).resolve().relative_to(ROOT))
 except Exception:return str(p)
def run(cmd):
 p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True); rp=None
 for l in p.stdout.splitlines():
  if l.startswith('REPORT_PATH='): rp=l.split('=',1)[1]
 return {'cmd':' '.join(cmd),'rc':p.returncode,'report_path':rp,'stdout_tail':p.stdout[-1500:],'stderr_tail':p.stderr[-1500:]}
def main():
 steps=[run([sys.executable,'-m','py_compile','scripts/lucidota_mega_gate.py','scripts/cep_full_e2e.py','scripts/mega_gate_metrics_validator.py','scripts/tickletrunk_scan.py','scripts/lucidota_status_ledger.py','scripts/dev_order_matrix_wrapper.py','scripts/matrix_trace_checker.py','scripts/dev_order_gate.py','scripts/run_dev_order_methodology_checks.py']),run([sys.executable,'scripts/cep_full_e2e.py','--dry-run','--operator-instruction','CI golden path dry-run guard']),run([sys.executable,'scripts/tickletrunk_scan.py','--execute']),run([sys.executable,'scripts/tickletrunk_scan.py','--check']),run([sys.executable,'scripts/lucidota_status_ledger.py','--check']),run([sys.executable,'scripts/run_dev_order_methodology_checks.py']),run([sys.executable,'scripts/boring_beast_full_e2e.py']),run([sys.executable,'scripts/lucidota_mega_gate.py'])]
 blockers=[s['cmd'] for s in steps if s['rc']!=0]
 payload={'action':'lucidota_ci_gate','steps':steps,'blockers':blockers,'status':'PASS' if not blockers else 'FAIL'}; OUT.mkdir(parents=True,exist_ok=True); p=OUT/f'lucidota_ci_gate_{ts()}.json'; payload['report_path']=rel(p); p.write_text(json.dumps(payload,indent=2),encoding='utf-8'); print('REPORT_PATH='+rel(p)); print('LUCIDOTA_CI_GATE='+payload['status']); return 0 if not blockers else 4
if __name__=='__main__': raise SystemExit(main())
