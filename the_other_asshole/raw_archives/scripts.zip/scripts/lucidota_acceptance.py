#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from case_workspace import CaseWorkspace
from kernel_control_packet import absurd_enqueue_packet
from lucidota_cli import cmd_new_case, cmd_submit_absurd
from spine_job_adapter import ABSURDJobAdapter
from work_order_importer import submit_pipeline_jobs
from absurd_worker_runner import drain
from case_dashboard_data import compile_dashboard_data
from case_packet_renderer import render_case_packet
from export_bundle import export_bundle, verify_bundle
from import_export_bundle import import_bundle_read_only
from spine_common import write_json

class Args: pass

def run_acceptance(*, source: str|Path, base_dir: str|Path, case_id: str='acceptance-case') -> dict:
    ws=CaseWorkspace.create(case_id, base_dir=base_dir)
    adapter=ABSURDJobAdapter(ws.root/'absurd')
    submit_pipeline_jobs(adapter=adapter, case_id=case_id, source_folder=str(source))
    drained=drain(adapter, base_dir=base_dir)
    packet_path=ws.root/'workspace'/'case_packet.json'
    packet=json.loads(packet_path.read_text())
    dashboard=compile_dashboard_data(case_id=case_id,custody={'package':packet.get('custody_refs',{}),'quarantine':[]},timeline={'claim_count':packet.get('timeline_refs',{}).get('claim_count',0),'timeline':[]},claims=[],contradictions=[],next_actions=[],receipts=packet.get('receipt_refs',[]),output_path=ws.root/'workspace'/'dashboard_data.json')
    render=render_case_packet(packet, md_path=ws.root/'workspace'/'case_packet.md', html_path=ws.root/'workspace'/'case_packet.html')
    exp=export_bundle(files=[packet_path, ws.root/'workspace'/'dashboard_data.json'], output_path=ws.root/'exports'/'case.tar.gz')
    ver=verify_bundle(ws.root/'exports'/'case.tar.gz') if exp['status']=='PASSED' else {'status':'SKIPPED'}
    imp=import_bundle_read_only(ws.root/'exports'/'case.tar.gz', case_id=case_id+'-imported', base_dir=Path(base_dir)) if ver['status']=='PASSED' else {'status':'SKIPPED'}
    result={'status':'PASSED' if drained['processed_count']==6 and exp['status']=='PASSED' and ver['status']=='PASSED' and imp['status']=='PASSED' else 'FAILED','drained':drained,'case_packet':str(packet_path),'dashboard':dashboard['dashboard_data_path'],'render':render,'export':exp,'verify':ver,'import':imp}
    write_json(ws.root/'acceptance_result.json',result); return result
