#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.engine.receipts import OUT, stamp
from ahoy_sim.training.xgb_shap_pipeline import apply_xgb_or_treelite


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=Path, required=True)
    ap.add_argument("--artifacts", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--target", default="resolved_effect")
    ap.add_argument("--no-treelite", action="store_true")
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()
    out_path = args.out or (OUT / "models" / f"treelite_apply_{stamp()}.json")
    receipt = apply_xgb_or_treelite(args.dataset, args.artifacts, out_path, target=args.target, use_treelite=not args.no_treelite, limit=args.limit)
    print(json.dumps({"verdict": receipt["verdict"], "engine": receipt["engine"], "rows": receipt["rows"], "accuracy": receipt["accuracy"], "macro_f1": receipt["macro_f1"], "receipt": str(out_path)}, sort_keys=True))
    return 0 if receipt["verdict"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
