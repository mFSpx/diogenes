#!/usr/bin/env python3
from __future__ import annotations
import html, json
from pathlib import Path
from typing import Any

def render_case_packet(packet: dict[str,Any], *, md_path: str|Path, html_path: str|Path) -> dict[str,str]:
    lines=[f"# Case Packet {packet.get('case_id')}", '', f"Packet: `{packet.get('packet_id')}`", '', '## Evidence Refs']
    for r in packet.get('receipt_refs',[]): lines.append(f'- `{r}`')
    lines += ['', '## Timeline', json.dumps(packet.get('timeline_refs',{}),indent=2), '', '## Claims', json.dumps(packet.get('claim_refs',{}),indent=2), '', '## Graph Candidates', json.dumps(packet.get('graph_candidate_refs',{}),indent=2)]
    md='\n'.join(lines)+'\n'
    Path(md_path).parent.mkdir(parents=True,exist_ok=True); Path(html_path).parent.mkdir(parents=True,exist_ok=True)
    Path(md_path).write_text(md,encoding='utf-8')
    body=''.join(f'<p>{html.escape(line)}</p>' for line in lines)
    Path(html_path).write_text(f'<!doctype html><html><body>{body}</body></html>',encoding='utf-8')
    return {'markdown_path':str(md_path),'html_path':str(html_path)}
