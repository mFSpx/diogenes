#!/usr/bin/env python3
from __future__ import annotations
from itertools import combinations
from typing import Any
from spine_common import sha256_json, now
NEGATORS=['did not ', 'does not ', 'is not ', 'are not ', 'not ','never ','false','no ']

def _norm(text): return ' '.join(text.lower().replace('.','').split())
def _base(text):
    t=_norm(text)
    for n in NEGATORS: t=t.replace(n,'')
    words=[]
    for w in t.split():
        if w.endswith('ed') and len(w)>4: w=w[:-2]
        words.append(w)
    return ' '.join(words).strip()
def _neg(text): return any(n in _norm(text) for n in NEGATORS)

def detect_contradictions(claims: list[dict[str,Any]]) -> list[dict[str,Any]]:
    out=[]
    for a,b in combinations(claims,2):
        if _base(a['claim_text']) == _base(b['claim_text']) and _neg(a['claim_text']) != _neg(b['claim_text']):
            rec={'contradiction_id':'contra:'+sha256_json({'a':a['claim_id'],'b':b['claim_id']})[:24], 'severity':'HIGH', 'claim_ids':[a['claim_id'],b['claim_id']], 'entity_refs':list(set(a.get('entity_candidates',[])+b.get('entity_candidates',[]))), 'event_refs':[], 'source_refs':[a.get('source_ref'),b.get('source_ref')], 'resolution_status':'OPEN', 'created_at':now()}
            out.append(rec)
    return out

def set_resolution(record: dict[str,Any], status: str, *, reason: str) -> dict[str,Any]:
    if status not in {'RESOLVED','DISMISSED'}: raise ValueError('invalid resolution status')
    r=dict(record); r['resolution_status']=status; r['resolution_reason']=reason; r['resolved_at']=now(); return r
