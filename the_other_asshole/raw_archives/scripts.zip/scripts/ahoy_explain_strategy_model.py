#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.training.explain_strategy_model import compute_prediction_and_shap, explain_strategy_model


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--training-row", type=Path, required=True)
    ap.add_argument("--prediction", type=Path)
    ap.add_argument("--shap", type=Path)
    ap.add_argument("--model", type=Path)
    ap.add_argument("--model-metadata", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    prediction_path = args.prediction
    shap_path = args.shap
    if args.model and not prediction_path and not shap_path:
        row = json.loads(args.training_row.read_text())
        pred, shap = compute_prediction_and_shap(row, args.model)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        prediction_path = args.out.parent / (args.out.stem + "_prediction.json")
        shap_path = args.out.parent / (args.out.stem + "_shap.json")
        prediction_path.write_text(json.dumps(pred, indent=2, sort_keys=True))
        shap_path.write_text(json.dumps(shap, indent=2, sort_keys=True))
    packet = explain_strategy_model(args.training_row, prediction_path, shap_path, args.out, model_metadata_path=args.model_metadata)
    print(json.dumps({"verdict": "PASS", "out": str(args.out), "evidence": len(packet["ontology"]["EVIDENCE"])}, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
