#!/usr/bin/env python3
"""System-wide graph safety audit: orphan/direct-write/materialization/journal checks."""
from __future__ import annotations
import json,subprocess,sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'05_OUTPUTS/graph'
def stamp(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def rel(p):
 try: return str(Path(p).resolve().relative_to(ROOT))
 except Exception: return str(p)
def run(cmd):
 p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True); rp=None
 for line in p.stdout.splitlines():
  if line.startswith('REPORT_PATH='): rp=line.split('=',1)[1]
 return {'command':' '.join(cmd),'rc':p.returncode,'report_path':rp,'stdout_tail':p.stdout[-1500:],'stderr_tail':p.stderr[-1500:]}
def main():
 steps=[run([sys.executable,'scripts/graph_promotion_orphan_detector.py']),run([sys.executable,'scripts/graph_write_blocker_probe.py']),run([sys.executable,'scripts/graph_edge_write_blocker_probe.py','--execute']),run([sys.executable,'scripts/graph_journal_replay_audit.py']),run([sys.executable,'scripts/graph_canonical_mutation_detector.py'])]
 blockers=[f"failed:{s['command']}" for s in steps if s['rc']!=0]
 payload={'action':'system_graph_safety_audit','steps':steps,'blockers':blockers,'status':'PASS' if not blockers else 'FAIL'}
 OUT.mkdir(parents=True,exist_ok=True); p=OUT/f'system_graph_safety_audit_{stamp()}.json'; payload['generated_at']=datetime.now(timezone.utc).isoformat().replace('+00:00','Z'); payload['report_path']=rel(p); p.write_text(json.dumps(payload,indent=2),encoding='utf-8'); print('REPORT_PATH='+rel(p)); print('SYSTEM_GRAPH_SAFETY='+payload['status']); return 0 if not blockers else 4
if __name__=='__main__': raise SystemExit(main())
