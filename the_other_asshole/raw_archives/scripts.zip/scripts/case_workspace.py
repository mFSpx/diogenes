#!/usr/bin/env python3
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from spine_common import ROOT, now, rel, write_json, sha256_json
from import_policy import ImportPolicy

CASE_ID_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$')


def validate_case_id(case_id: str) -> str:
    if not CASE_ID_RE.match(case_id):
        raise ValueError('invalid case_id')
    return case_id


@dataclass(frozen=True)
class CaseWorkspace:
    case_id: str
    root: Path
    read_only: bool = False

    @classmethod
    def create(cls, case_id: str, *, base_dir: str | Path | None = None, read_only: bool = False) -> 'CaseWorkspace':
        case_id = validate_case_id(case_id)
        base = Path(base_dir) if base_dir else ROOT / '05_OUTPUTS/cases'
        root = base / case_id
        root.mkdir(parents=True, exist_ok=True)
        for sub in ['content_store', 'receipts', 'runs', 'exports', 'workspace']:
            (root / sub).mkdir(parents=True, exist_ok=True)
        meta = {'schema':'lucidota.case_workspace.v1','case_id':case_id,'root':rel(root),'read_only':read_only,'created_or_seen_at':now()}
        write_json(root / 'case_workspace.json', meta)
        return cls(case_id=case_id, root=root, read_only=read_only)

    def path(self, *parts: str) -> Path:
        p = self.root.joinpath(*parts)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def assert_writable(self) -> None:
        if self.read_only:
            raise PermissionError(f'case workspace {self.case_id} is read-only')

    def scoped_ref(self, payload: Any) -> str:
        return f'case:{self.case_id}:{sha256_json(payload)[:24]}'

    def write_import_policy(self, policy: ImportPolicy) -> Path:
        self.assert_writable()
        return write_json(self.root / 'import_policy.json', policy.as_dict())

    def load_import_policy(self) -> ImportPolicy:
        p=self.root / 'import_policy.json'
        if not p.exists():
            return ImportPolicy()
        import json
        return ImportPolicy.from_dict(json.loads(p.read_text(encoding='utf-8')))
