#!/usr/bin/env python3
from __future__ import annotations

def validate_vram_budget(*, requested_vram_mb:int, available_vram_mb:int=4096, reserve_mb:int=512) -> dict:
    usable=max(0,available_vram_mb-reserve_mb)
    if requested_vram_mb > usable:
        return {'ok':False,'error':'VRAM_BUDGET_EXCEEDED','requested_vram_mb':requested_vram_mb,'usable_vram_mb':usable}
    return {'ok':True,'requested_vram_mb':requested_vram_mb,'usable_vram_mb':usable}
