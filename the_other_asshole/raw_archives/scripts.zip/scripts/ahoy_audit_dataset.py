#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.training.dataset_audit import audit_dataset


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("dataset", type=Path)
    ap.add_argument("--min-distinct-labels-per-faction", type=int, default=5)
    args = ap.parse_args()
    result = audit_dataset(args.dataset, min_distinct_labels_per_faction=args.min_distinct_labels_per_faction)
    print(json.dumps(result, sort_keys=True))
    return 0 if result["verdict"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
