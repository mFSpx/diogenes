#!/usr/bin/env python3
"""Full Boring Beast E2E verifier.

Runs the core Boring Beast E2E, proves duplicate suppression, verifies direct
graph writes stay blocked, derives status ledger facts, and emits one compact
machine report.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "05_OUTPUTS/boring_beast"


def now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def rel(p: Path | str) -> str:
    try:
        return str(Path(p).resolve().relative_to(ROOT))
    except Exception:
        return str(p)


def safe_env() -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("LUCIDOTA_OUTBOUND_STATE", "draft_only")
    env.setdefault("LUCIDOTA_EXTERNAL_WRITES", "draft_only")
    return env


def run(cmd: list[str], *, timeout: int) -> dict[str, Any]:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True, timeout=timeout, env=safe_env())
    return {
        "command": " ".join(cmd),
        "returncode": proc.returncode,
        "stdout_tail": proc.stdout[-3000:],
        "stderr_tail": proc.stderr[-3000:],
        "passed": proc.returncode == 0,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Bounded Boring Beast E2E verifier")
    ap.add_argument("--timeout-seconds", type=int, default=180)
    args = ap.parse_args()
    timeout = max(30, min(int(args.timeout_seconds), 900))
    commands = [
        run([sys.executable, "scripts/boring_beast.py", "e2e", "--execute"], timeout=timeout),
        run([sys.executable, "scripts/graph_write_blocker_probe.py"], timeout=timeout),
        run([sys.executable, "scripts/runtime_status_ledger_updater.py", "--execute"], timeout=timeout),
        run([sys.executable, "scripts/lucidota_status_ledger.py", "--check"], timeout=timeout),
    ]
    passed = all(c["passed"] for c in commands)
    report = {
        "schema": "lucidota.boring_beast.full_e2e.v1",
        "generated_at": now(),
        "execute_performed": True,
        "timeout_seconds": timeout,
        "db_writes_performed": True,
        "graph_writes_performed": False,
        "commands": commands,
        "pass": passed,
        "blockers": [] if passed else ["one_or_more_full_e2e_commands_failed"],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    out = OUT / f"boring_beast_full_e2e_{stamp()}.json"
    report["report_path"] = rel(out)
    out.write_text(json.dumps(report, indent=2, sort_keys=False, default=str), encoding="utf-8")
    print(f"REPORT_PATH={rel(out)}")
    print("BORING_BEAST_FULL_E2E=" + ("PASS" if passed else "FAIL"))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
