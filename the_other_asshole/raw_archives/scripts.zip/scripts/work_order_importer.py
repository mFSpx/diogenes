#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from typing import Any
from spine_job_adapter import ABSURDJobAdapter
from spine_common import sha256_json
STAGES=['intake','parse','timeline','staging','graph_candidate','case_packet']

def submit_pipeline_jobs(*, adapter: ABSURDJobAdapter, case_id: str, source_folder: str) -> list[dict[str,Any]]:
    jobs=[]; prev=None
    for stage in STAGES:
        payload={'case_id':case_id,'stage':stage,'source_folder':source_folder}
        job=adapter.create_job(lane=f'pipeline.{stage}', payload=payload, idempotency_key=sha256_json(payload), depends_on=[prev] if prev else [])
        jobs.append(job); prev=job['job_id']
        if job['state']=='CREATED': adapter.transition(job['job_id'],'QUEUED')
    return jobs


def work_orders_from_next_actions(actions: list[dict]) -> list[dict]:
    return [{'work_order_id':'wo:'+a['action_id'].split(':',1)[1], 'kind':'missing_evidence', 'target_ref':a['target_ref'], 'instruction':a['plain_language_instruction'], 'closure_gate':a['closure_gate'], 'status':'CREATED'} for a in actions]
