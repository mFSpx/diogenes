#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.ontology.strategy_adapter import explain_model_packet, ontology_packet_from_training_row
from ahoy_sim.training.strategy_dataset import raw_row_to_strategy_training_row, default_feature_schema


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("packet")
    p.add_argument("--state-row", type=Path, required=True)
    p.add_argument("--feature-schema", type=Path)
    p.add_argument("--out", type=Path, required=True)
    e = sub.add_parser("explain-model")
    e.add_argument("--training-row", type=Path, required=True)
    e.add_argument("--prediction", type=Path, required=True)
    e.add_argument("--shap", type=Path)
    e.add_argument("--out", type=Path, required=True)
    ap.add_argument("--state-row", type=Path)
    ap.add_argument("--feature-schema", type=Path)
    ap.add_argument("--prediction", type=Path)
    ap.add_argument("--shap", type=Path)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args()
    if args.cmd == "explain-model":
        row = json.loads(args.training_row.read_text())
        pred = json.loads(args.prediction.read_text())
        shap = json.loads(args.shap.read_text()) if args.shap else None
        packet = explain_model_packet(row, pred, shap)
        _write(args.out, packet)
        out = args.out
    else:
        state_row = args.state_row
        out = args.out
        if not state_row or not out:
            ap.error("packet mode requires --state-row and --out")
        raw = json.loads(state_row.read_text())
        schema = json.loads(args.feature_schema.read_text()) if args.feature_schema and args.feature_schema.exists() else default_feature_schema()
        training_row = raw if raw.get("schema") == "lucidota.ahoy.strategy_training_row.v1" else raw_row_to_strategy_training_row(raw, schema, future_raw_row=raw, future_window=0)
        packet = ontology_packet_from_training_row(training_row)
        _write(out, packet)
    print(json.dumps({"verdict": "PASS", "out": str(out)}, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
