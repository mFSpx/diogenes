#!/usr/bin/env python3
"""On-demand durable Ahoy workflow controller backed by Absurd state.

This wrapper does not auto-start. It only launches when explicitly asked, stores
its durable state in lucidota_control.absurd_workflow, and can be stopped
cleanly by status transition + process-group termination.
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.runtime_dsns import resolve_state_dsn

AHOY = ROOT / "scripts" / "ahoy_million_replay.py"
WORKFLOW_NAME = "ahoy_million_replay"


def now_z() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def jdump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def rel(path: Path | str) -> str:
    try:
        return str(Path(path).resolve().relative_to(ROOT))
    except Exception:
        return str(path)


def state_dsn() -> str:
    return resolve_state_dsn()


def ensure_schema() -> None:
    with psycopg.connect(state_dsn()) as conn:
        conn.execute(
            """
            CREATE EXTENSION IF NOT EXISTS pgcrypto;
            CREATE SCHEMA IF NOT EXISTS lucidota_control;
            CREATE TABLE IF NOT EXISTS lucidota_control.absurd_workflow (
                workflow_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                workflow_name text NOT NULL,
                status text NOT NULL DEFAULT 'pending',
                state jsonb NOT NULL DEFAULT '{}'::jsonb,
                payload jsonb NOT NULL DEFAULT '{}'::jsonb,
                error_log text,
                created_at timestamptz NOT NULL DEFAULT now(),
                updated_at timestamptz NOT NULL DEFAULT now()
            );
            ALTER TABLE lucidota_control.absurd_workflow
                ADD COLUMN IF NOT EXISTS priority integer NOT NULL DEFAULT 100,
                ADD COLUMN IF NOT EXISTS attempt_count integer NOT NULL DEFAULT 0,
                ADD COLUMN IF NOT EXISTS failure_count integer NOT NULL DEFAULT 0,
                ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 4,
                ADD COLUMN IF NOT EXISTS locked_by text,
                ADD COLUMN IF NOT EXISTS locked_at timestamptz,
                ADD COLUMN IF NOT EXISTS lease_expires_at timestamptz,
                ADD COLUMN IF NOT EXISTS completed_at timestamptz,
                ADD COLUMN IF NOT EXISTS last_comment_uuid uuid;
            CREATE UNIQUE INDEX IF NOT EXISTS uq_absurd_workflow_name
                ON lucidota_control.absurd_workflow(workflow_name);
            CREATE INDEX IF NOT EXISTS idx_absurd_workflow_status
                ON lucidota_control.absurd_workflow(status);
            CREATE INDEX IF NOT EXISTS idx_absurd_workflow_claim_pending
                ON lucidota_control.absurd_workflow(priority ASC, created_at ASC)
                WHERE status = 'pending';
            CREATE INDEX IF NOT EXISTS idx_absurd_workflow_running_lease
                ON lucidota_control.absurd_workflow(lease_expires_at)
                WHERE status = 'running';
            """
        )
        conn.commit()


def upsert_workflow(config: dict[str, Any]) -> dict[str, Any]:
    ensure_schema()
    with psycopg.connect(state_dsn(), row_factory=dict_row) as conn:
        row = conn.execute(
            """
            INSERT INTO lucidota_control.absurd_workflow(workflow_name, status, state, payload, priority, max_attempts)
            VALUES (%s, 'pending', %s::jsonb, %s::jsonb, %s, %s)
            ON CONFLICT (workflow_name) DO UPDATE
            SET status = EXCLUDED.status,
                state = EXCLUDED.state,
                payload = EXCLUDED.payload,
                priority = EXCLUDED.priority,
                max_attempts = EXCLUDED.max_attempts,
                updated_at = now()
            RETURNING workflow_id::text, workflow_name, status, state, payload, created_at::text, updated_at::text
            """,
            (WORKFLOW_NAME, jdump(config.get("state") or {}), jdump(config.get("payload") or {}), int(config.get("priority") or 100), int(config.get("max_attempts") or 4)),
        ).fetchone()
        conn.commit()
    return dict(row)


def fetch_workflow() -> dict[str, Any] | None:
    ensure_schema()
    with psycopg.connect(state_dsn(), row_factory=dict_row) as conn:
        row = conn.execute(
            """
            SELECT workflow_id::text, workflow_name, status, state, payload, error_log,
                   attempt_count, failure_count, max_attempts, locked_by,
                   locked_at::text, lease_expires_at::text, completed_at::text,
                   created_at::text, updated_at::text
            FROM lucidota_control.absurd_workflow
            WHERE workflow_name=%s
            ORDER BY updated_at DESC
            LIMIT 1
            """,
            (WORKFLOW_NAME,),
        ).fetchone()
    return dict(row) if row else None


def update_status(status: str, *, pid: int | None = None, error_log: str | None = None) -> dict[str, Any] | None:
    ensure_schema()
    with psycopg.connect(state_dsn(), row_factory=dict_row) as conn:
        row = conn.execute(
            """
            UPDATE lucidota_control.absurd_workflow
            SET status=%s,
                locked_by=%s::text,
                locked_at=CASE WHEN %s::int IS NOT NULL THEN now() ELSE locked_at END,
                lease_expires_at=CASE WHEN %s::int IS NOT NULL THEN now() + interval '1 hour' ELSE lease_expires_at END,
                completed_at=CASE WHEN %s::text IN ('completed','failed','cancelled','dead_lettered') THEN now() ELSE completed_at END,
                error_log=COALESCE(%s::text, error_log),
                updated_at=now()
            WHERE workflow_name=%s
            RETURNING workflow_id::text, workflow_name, status, state, payload, error_log,
                      attempt_count, failure_count, max_attempts, locked_by,
                      locked_at::text, lease_expires_at::text, completed_at::text,
                      created_at::text, updated_at::text
            """,
            (status, str(pid) if pid is not None else None, pid, pid, status, error_log, WORKFLOW_NAME),
        ).fetchone()
        conn.commit()
    return dict(row) if row else None


def launch(args: argparse.Namespace) -> int:
    payload = {
        "run_id": args.run_id,
        "iterations": args.iterations,
        "games_per_iteration": args.games_per_iteration,
        "workers": args.workers,
        "seed": args.seed,
        "max_rounds": args.max_rounds,
        "future_window": args.future_window,
        "sample_cap": args.sample_cap,
        "ontology_sample_cap": args.ontology_sample_cap,
        "train_rows_cap": args.train_rows_cap,
        "targets": args.targets,
        "quick_grid": bool(args.quick_grid),
        "replay_only": bool(args.replay_only),
        "out_root": str(args.out_root),
    }
    row = upsert_workflow({"priority": args.priority, "max_attempts": args.max_attempts, "payload": payload, "state": {"mode": "pending", "auto_start": False}})
    if not args.start:
        print(json.dumps({"workflow": row, "action": "enqueued", "auto_start": False}, sort_keys=True))
        return 0
    out_dir = Path(args.out_root) / args.run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        str(AHOY),
        "run",
        "--run-id",
        args.run_id,
        "--out-root",
        str(args.out_root),
        "--iterations",
        str(args.iterations),
        "--games-per-iteration",
        str(args.games_per_iteration),
        "--workers",
        str(args.workers),
        "--seed",
        str(args.seed),
        "--max-rounds",
        str(args.max_rounds),
        "--future-window",
        str(args.future_window),
        "--sample-cap",
        str(args.sample_cap),
        "--ontology-sample-cap",
        str(args.ontology_sample_cap),
        "--train-rows-cap",
        str(args.train_rows_cap),
        "--targets",
        args.targets,
    ]
    if args.quick_grid:
        cmd.append("--quick-grid")
    if args.replay_only:
        cmd.append("--replay-only")
    proc = subprocess.Popen(cmd, cwd=ROOT, start_new_session=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    update_status("running", pid=proc.pid, error_log=None)
    state = {"pid": proc.pid, "cmd": cmd, "out_dir": rel(out_dir), "launched_at": now_z()}
    with psycopg.connect(state_dsn()) as conn:
        conn.execute(
            """
            UPDATE lucidota_control.absurd_workflow
            SET state = state || %s::jsonb,
                payload = payload || %s::jsonb,
                updated_at = now()
            WHERE workflow_name=%s
            """,
            (jdump(state), jdump({"launch_state": "running"}), WORKFLOW_NAME),
        )
        conn.commit()
    print(json.dumps({"action": "launched", "workflow_name": WORKFLOW_NAME, "pid": proc.pid, "run_id": args.run_id, "out_dir": rel(out_dir)}, sort_keys=True))
    return 0


def stop(args: argparse.Namespace) -> int:
    row = fetch_workflow()
    pid = None
    if row:
        state = row.get("state") or {}
        pid = state.get("pid")
    if args.pid:
        pid = args.pid
    if pid is not None:
        try:
            os.killpg(int(pid), signal.SIGTERM)
        except Exception:
            try:
                os.kill(int(pid), signal.SIGTERM)
            except Exception:
                pass
    update_status("cancelled", pid=None, error_log=args.reason or "operator stop requested")
    print(json.dumps({"action": "stopped", "workflow_name": WORKFLOW_NAME, "pid": pid, "reason": args.reason}, sort_keys=True))
    return 0


def status(args: argparse.Namespace) -> int:
    row = fetch_workflow()
    print(json.dumps({"workflow": row, "workflow_name": WORKFLOW_NAME}, indent=2, sort_keys=True, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Durable on-demand Ahoy workflow controller (Absurd-backed)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    lp = sub.add_parser("launch")
    lp.add_argument("--run-id", default=stamp())
    lp.add_argument("--out-root", type=Path, default=ROOT / "05_OUTPUTS/ahoy/million_replay")
    lp.add_argument("--iterations", type=int, default=10)
    lp.add_argument("--games-per-iteration", type=int, default=100000)
    lp.add_argument("--workers", type=int, default=max(1, os.cpu_count() or 1))
    lp.add_argument("--seed", type=int, default=414000000)
    lp.add_argument("--max-rounds", type=int, default=6)
    lp.add_argument("--future-window", type=int, default=3)
    lp.add_argument("--sample-cap", type=int, default=60000)
    lp.add_argument("--ontology-sample-cap", type=int, default=5000)
    lp.add_argument("--train-rows-cap", type=int, default=80000)
    lp.add_argument("--targets", default="primary_dynamic_label,winning_entity_role,mode_authority,mode_insurgent,mode_opportunist,topology_control_label,extraction_label,leverage_starvation_threshold_crossed,friction_overload_threshold_crossed,visibility_overextension_threshold_crossed,choke_point_dominance_threshold_crossed,opportunist_extraction_window_open")
    lp.add_argument("--quick-grid", action="store_true")
    lp.add_argument("--replay-only", action="store_true")
    lp.add_argument("--priority", type=int, default=100)
    lp.add_argument("--max-attempts", type=int, default=4)
    lp.add_argument("--start", action=argparse.BooleanOptionalAction, default=False, help="actually launch the Ahoy runner; otherwise only enqueue durable state")
    lp.set_defaults(func=launch)

    sp = sub.add_parser("stop")
    sp.add_argument("--pid", type=int)
    sp.add_argument("--reason", default="operator stop requested")
    sp.set_defaults(func=stop)

    zp = sub.add_parser("status")
    zp.set_defaults(func=status)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
