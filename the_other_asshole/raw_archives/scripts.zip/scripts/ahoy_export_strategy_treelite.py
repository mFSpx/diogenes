#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ahoy_sim.training.export_strategy_treelite import export_strategy_treelite


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--receipt-out", type=Path, required=True)
    args = ap.parse_args()
    receipt = export_strategy_treelite(args.model, args.out, args.receipt_out)
    print(json.dumps({"verdict": receipt["verdict"], "treelite_exported": receipt.get("treelite_exported"), "out": str(args.out), "receipt": str(args.receipt_out)}, sort_keys=True))
    return 0 if receipt["verdict"] == "PASS" else 4

if __name__ == "__main__":
    raise SystemExit(main())
